<?php
require('model.php');

$posts = getBillets();

require('view.php');
